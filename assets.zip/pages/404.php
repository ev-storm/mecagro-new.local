	<title>mecagro | 404</title>
	<?php include "../components/head.php"?>



<body>
	<?php include "../components/menu.php"?>



	<div class="container-404">


		<h1>404</h1>
		<h2>Такой страницы нет</h2>
		<a href="/"><button class="btn btn-404">Главная</button></a>



	</div>


	<?php include "../components/modal.php"?>





</body>
</html>