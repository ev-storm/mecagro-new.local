	<title>mecagro | Новости</title>
	<?php include "../components/head.php"?>

	<style>
			.news-btn{
				color: #58c88a!important;
			}
	</style>

<body>
	<?php include "../components/menu.php"?>

	<?php include "../components/modal.php"?>


	<div class="container">
	


	<?php include "../components/footer.php"?>
	</div>


</body>
</html>