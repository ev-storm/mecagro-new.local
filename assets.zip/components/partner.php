		<div class="anim-left partners-con">
			<div class="partners-title">
				<div class="title-heading-con">
					<h1 class="anim-left title-heading">Наши партнёры</h1>
					<h2>ООО «МЕКАГРО ГРУП» является официальным дилером компаний:<br>
						<span>MECAGRO, TIERRE, BERTOLINI, ARAG.</span>
					</h2>
				</div>
			</div>
		</div>

		<div class="swiper brendMainSwiper">
			<div class="swiper-wrapper">
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
			</div>
		</div>