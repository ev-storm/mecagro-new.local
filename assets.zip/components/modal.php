<div class="modal-con hide-prev">
	<div class="modal">
			<img class="modal-logo" src="/assets/svg/logo.svg" alt="">
			<img class="close-modal" src="/assets/svg/close-green.svg" alt="">
		<form class="modal-form form" action="#" method="POST">
				<input type="hidden" name="Заявка" value="Обратная связь">
			<input  class="input-name-modal" type="text" name="Имя" placeholder="Ваше имя">
			<input class="input-tel-modal" type="tel" name="Телефон" placeholder="Телефон">
			<input class="input-mail" type="email" name="E-mail" placeholder="E-mail">
			<textarea class="input-commet" name="Комментарий" placeholder="Введите комментарий" rows="2"></textarea>
			<button class="btn btn-modal" disanle="true">Отправить</button>

				<label class="check-form" for="check-form-id">
					<input id="check-form-id" type="checkbox">
					<span>Согласен с обработкой персональных данных в соответствии с <a href="/pages/about.php#policy">политикой конфиденциальности</a></span>
				</label>			

				<div class="link link-form">
						<a href="#"><img src="/assets/svg/link/wt.svg" alt=""></a>
						<a href="#"><img src="/assets/svg/link/tg.svg" alt=""></a>
						<a href="#"><img src="/assets/svg/link/ml.svg" alt=""></a>
						<a href="#"><img src="/assets/svg/link/vk.svg" alt=""></a>
						<a href="#"><img src="/assets/svg/link/tel.svg" alt=""></a>
					</div>

		</form>
	</div>
</div>