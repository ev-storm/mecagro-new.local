		<div class="anim-left partners-con">
			<div class="partners-title">
				<div class="title-heading-con">
					<h1 data-lang="Наши партнёры" data-lang_en="Our partners" class="anim-left title-heading">Наши партнёры</h1>
					<h2 data-lang="ООО «МЕКАГРО ГРУП» является официальным дилером компаний:" data-lang_en="LLC «MEKAGRO GROUP» is an official dealer of the companies:">ООО «МЕКАГРО ГРУП» является официальным дилером компаний:<br>
						<span>MECAGRO, TIERRE, BERTOLINI, ARAG.</span>
					</h2>
				</div>
			</div>
		</div>

		<div class="swiper brendMainSwiper">
			<div class="swiper-wrapper">
				<div class="swiper-slide brend-slide">
					<img src="/assets/svg/brend/1.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
						<img src="/assets/svg/brend/2.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
						<img src="/assets/svg/brend/3.svg" alt="">
				</div>
				<div class="swiper-slide brend-slide">
						<img src="/assets/svg/brend/4.svg" alt="">
				</div>
			</div>
		</div>