			<div class="categories-con">
					<ul class="filter-categories">
						<li><h2></h2>
							<ul>
								<li class="filter brend-btn active"><h2>MECARGO</h2></li>
								<li><h2>|</h2></li>
								<li class="filter brend-btn active"><h2>BARGAM</h2></li>
								<li><h2>|</h2></li>
								<li class="filter brend-btn active"><h2>MOSH</h2></li>
							</ul>
						</li>
						<li class="filter filter-btn"><h2 data-lang="Популярное" data-lang_en="Popular">Популярное</h2></li>
						<li class="filter filter-btn"><h2 data-lang="Новинка" data-lang_en="New">Новинка</h2></li>
					</ul>
					<div class="categories-margin"></div>
					<ul class="main-categories"></ul>
					<div class="download-cat-mob">
						<button class="btn-light download-cat">Скачать каталог
							<ul>
								<li><a target="_blanc" href="/assets/img/brend/Mecagro.pdf"><h2>MECARGO PDF</h2></a></li>
								<li><a target="_blanc" href="/assets/img/brend/BARGAM.pdf"><h2>BARGAM PDF</h2></a></li>
								<li><a target="_blanc" href="/assets/img/brend/Mosh.pdf"><h2>MOSH PDF</h2></a></li>
							</ul>
						</button>
							<div class="mob-cat-btn-con">
								<img class="open-cat-menu" src="/assets/svg/catalog-open-mob.svg" alt="">
								<img class="close-cat-menu hide" src="/assets/svg/catalog-close-mob.svg" alt="">
							</div>
					</div>
			</div>