	<div class="anim-left main-description-con">
			<div class="main-description">
				<h1 data-lang="ООО «МЕКАГРО ГРУП» - официальный дилер компаний MECAGRO, TIERRE, BERTOLINI и ARAG на территории России и стран СНГ" data-lang_en="MECAGRO GROUP LLC is the official dealer of MECAGRO, TIERRE, BERTOLINI and ARAG companies in Russia and the CIS countries.">ООО «МЕКАГРО ГРУП» - официальный дилер компаний MECAGRO, TIERRE, BERTOLINI и ARAG на территории России и стран СНГ</h1>
				<h2 data-lang="Для вас мы готовы предоставить новинки в мире агротехнологий. Компании MECAGRO, TIERRE, BERTOLINI и ARAG закрывают все потребности в технике для агрохолдингов. Все модели доступны на нашем складе в России. Вы получаете оборудование без долгого ожидания — отгружаем в день оплаты. Предоставляем сертификаты качества. Выгодные цены за счёт отсутствия наценок." data-lang_en="We are ready to provide you with novelties in the world of agricultural technologies. MECAGRO, TIERRE, BERTOLINI and ARAG companies cover all the equipment needs for agricultural holdings. All models are available in our warehouse in Russia. You receive the equipment without a long wait — we ship it on the day of payment. We provide quality certificates. Favorable prices due to the absence of extra charges.">Для вас мы готовы предоставить новинки в мире аготехнологий. Компании MECAGRO, TIERRE, BERTOLINI и ARAG закрывают все потребности в технике для агрохолдингов. Все модели доступны на нашем складе в России. 
						Вы получаете оборудование без долгого ожидания — отгружаем в день оплаты. 
						Предоставляем сертификаты качества. 
						Выгодные цены за счёт отсутствия наценок.
				</h2>
				<button data-lang="Сертификаты" data-lang_en="Certificates" class="btn btn-download" >Сертификаты</button>
			</div>
		</div>