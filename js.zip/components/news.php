<div id="news" class="news-con">
	<div class="title-heading-con anim-left">
		<h1 data-lang="Новости компании" data-lang_en="Company News" class="title-heading">
			Новости компании
		</h1>
	</div>
	<div class="news">
			<div class="swiper news-swiper">
				<div class="swiper-wrapper news-swiper-wrapper">
					<!-- <div class="swiper-slide news-slide">
						<div class="news-img-con">
							<img src="/assets/img/news/1.png" alt="">
						</div>
						<div class="news-text">
							<h1>Запуск новой линии</h1>
							<h2>
							</h2>
							<div class="news-data">
								<span>26.04.2025</span>
							</div>
						</div>
					
					</div> -->
				</div>
				
				<div class="news-arrow">
					<img class="news-arrow_L" src="/assets/svg/title-link/L.svg" alt="">
					<img class="news-arrow_R" src="/assets/svg/title-link/R.svg" alt="">
				</div>
			</div>
		<div class="anim-up news-swiper-mini-con">
		  <div thumbsSlider="" class="swiper news-swiper-mini">
				<div class="swiper-wrapper news-swiper-wrapper-mini">
					<!-- <div class="swiper-slide news-slide">
						<h1>Запуск новой линии 
							<br><span>26.04.2025</span>
						</h1>
						<img src="/assets/img/news/1.png" alt="">
					</div> -->
				</div>
			</div>
			<img class="mini-news-arrow_L" src="/assets/svg/title-link/L.svg" alt="">
			<img class="mini-news-arrow_R" src="/assets/svg/title-link/R.svg" alt="">
		</div>
			

		
	</div>

</div>

	


