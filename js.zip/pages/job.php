	<title>mecagro | Вакансии</title>
	<?php include "../components/head.php"?>

	<!-- <style>
			.news-btn{
				color: #58c88a!important;
			}
	</style> -->

<body>
	<?php include "../components/menu.php"?>

	<?php include "../components/modal.php"?>

	<?php include "../components/categories.php"?>


	<div class="container">
		<div class="job-con">
			<div class="job-list-con">
				<div class="job-list-btn">
					<h2 class="job-list-btn-open">Показать все</h2>
					<h2 class="job-list-btn-close">Скрыть все</h2>
				</div>
				<ul class="job-list">
					<!-- <li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li>
					<li class="job-list-item">Название вакансии</li> -->
				</ul>
			</div>
			<div class="job-main-con">
				<!-- <div class="job-card">
					<div class="job-card-main">
						<div class="job-card-title-con">
							<img class="job-card-title-photo" src="/assets/svg/job/1.svg" alt="">
							<div class="job-card-title">
								<h1  class="job-card-title-h1">Название вакансии</h1>
								<div class="job-card-specifications">
									<h2>Опыт: Более трёх лет</h2>
									<h1>90 000 ₽</h1>
								</div>
							</div>
							<img class="job-card-title-arrow" src="/assets/svg/arrow-green.svg" alt="">
						</div>
						<div class="job-card-description">
							<h2>ООО «Мекагро Груп» представляет гарантию на всю продукцию, в том числе к каждой покупке мы предоставляем сертификаты соответствия. Мы готовы поддержать вас на протяжении всего срока службы оборудования, предоставляя помощь при возникновении любых вопросов.Мы закрываем вопрос с поставкой запчастей любой сложности для техники брендов MECAGRO, TIERRE, BERTOLINI и ARAG. Больше не нужно ждать месяцы или искать аналоги — все детали доступны на нашем складе и отправляются в день заказа!</h2>
						</div>
						<form class="job-form form" action="#" method="POST">
							<input type="hidden" name="Заявка" value="Вакансия">
							<input  class="input-name-modal" type="text" name="Имя" placeholder="Ваше имя">
							<textarea class="input-commet" name="Комментарий" placeholder="Введите комментарий" rows="4"></textarea>
							<div class="job-form-input">
								<input class="input-tel-modal" type="tel" name="Телефон" placeholder="Телефон">
								<button class="btn btn-form" disanle="true">Отправить</button>
							</div>
				
						</form>
							
					</div>
				</div> -->
			</div>
			
		</div>
	


	
	


	</div>
		<?php include "../components/footer.php"?>
	


</body>
</html>